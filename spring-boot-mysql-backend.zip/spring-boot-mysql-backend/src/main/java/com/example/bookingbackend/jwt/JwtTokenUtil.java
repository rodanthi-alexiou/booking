package com.example.bookingbackend.jwt;

import java.security.Key;
import java.util.Base64;

import java.util.Date;
 
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.security.Keys;

import com.example.bookingbackend.model.User;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

 



 
@Component
public class JwtTokenUtil {
    private static final long EXPIRE_DURATION = 24 * 60 * 60 * 1000; // 24 hour
     
    @Value("${app.jwt.secret}")
    private String SECRET_KEY;

    // private Key getSigningKey() {
    //     return Keys.hmacShaKeyFor(SECRET_KEY.getBytes());
    // }

    // Generate a secure key with at least 256 bits
    private Key key = Keys.secretKeyFor(SignatureAlgorithm.HS256);
     
    public String generateAccessToken(User user) {
        return Jwts.builder()
                .setSubject(String.format("%s,%s", user.getUser_id(), user.getUsername()))
                .setIssuer("CodeJava")
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRE_DURATION))
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();
                 
    }

        private static final Logger LOGGER = LoggerFactory.getLogger(JwtTokenUtil.class);
     
        public boolean validateAccessToken(String token) {
            try {
                Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token);
                return true;
            } catch (ExpiredJwtException ex) {
                LOGGER.error("JWT expired", ex.getMessage());
            } catch (IllegalArgumentException ex) {
                LOGGER.error("Token is null, empty or only whitespace", ex.getMessage());
            } catch (MalformedJwtException ex) {
                LOGGER.error("JWT is invalid", ex);
            } catch (UnsupportedJwtException ex) {
                LOGGER.error("JWT is not supported", ex);
            }
        
            return false;
        }
        
        public String getSubject(String token) {
            return parseClaims(token).getSubject();
        }
        
        private Claims parseClaims(String token) {
            return Jwts.parserBuilder()
                    .setSigningKey(key)
                    .build()
                    .parseClaimsJws(token)
                    .getBody();
        }
        
}